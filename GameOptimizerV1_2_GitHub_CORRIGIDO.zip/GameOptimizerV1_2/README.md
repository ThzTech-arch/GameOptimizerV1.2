# Game Optimizer V1.2

Versão preparada para o caminho mais simples de teste: **GitHub Actions**.

## O que funciona
- leitura de RAM usada/total;
- bateria;
- armazenamento livre;
- estado térmico do Android;
- seleção e abertura dos jogos suportados;
- modo seguro informativo.

## Jogos detectados
- Free Fire
- Free Fire MAX
- Minecraft
- Roblox
- Fortnite
- Blood Strike

## Segurança
O aplicativo não usa root, overclock, undervolt, alteração de arquivos dos jogos ou encerramento forçado de outros aplicativos. Ele não promete aumentar magicamente o FPS.

## Como gerar o APK pelo GitHub
1. Crie um repositório no GitHub.
2. Envie **todo o conteúdo desta pasta**, incluindo `.github/workflows/build-apk.yml`.
3. Abra a aba **Actions** do repositório.
4. Escolha **Build Game Optimizer APK**.
5. Toque em **Run workflow** se quiser iniciar manualmente.
6. Quando terminar com sucesso, abra a execução concluída.
7. Na seção **Artifacts**, baixe `GameOptimizer-V1.2-debug`.
8. Extraia o ZIP e instale `app-debug.apk` no celular.

O workflow configura Java 17 e Gradle 8.9 automaticamente e publica o APK como artefato do GitHub Actions.
