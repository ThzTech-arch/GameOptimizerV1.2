plugins { id("com.android.application") }

android {
    namespace = "com.gameoptimizer.v12"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gameoptimizer.v12"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "1.2"
    }
}

dependencies {
}
