package com.gameoptimizer.v12;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final class Game {
        final String name, pkg;
        Game(String name, String pkg) { this.name = name; this.pkg = pkg; }
        @Override public String toString() { return name; }
    }

    private final List<Game> games = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status, protection, ram, battery, storage, thermal;
    private Spinner spinner;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildGames();
        buildUi();
        updateInfo();
        handler.postDelayed(refresh, 1500);
    }

    private void buildGames() {
        games.add(new Game("Free Fire", "com.dts.freefireth"));
        games.add(new Game("Free Fire MAX", "com.dts.freefiremax"));
        games.add(new Game("Minecraft", "com.mojang.minecraftpe"));
        games.add(new Game("Roblox", "com.roblox.client"));
        games.add(new Game("Fortnite", "com.epicgames.fortnite"));
        games.add(new Game("Blood Strike", "com.netease.newspike"));
    }

    private TextView text(String value, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value); v.setTextSize(size); v.setTextColor(0xFF202124);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, 6, 0, 6);
        return v;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 28, 32, 28);
        scroll.addView(root);

        TextView title = text("Game Optimizer", 28, true);
        root.addView(title);
        root.addView(text("V1.2 • teste seguro no celular", 15, false));

        root.addView(text("Status do aparelho", 21, true));
        ram = text("RAM: —", 16, false); battery = text("Bateria: —", 16, false);
        storage = text("Armazenamento livre: —", 16, false); thermal = text("Estado térmico: —", 16, false);
        root.addView(ram); root.addView(battery); root.addView(storage); root.addView(thermal);

        root.addView(text("Jogo", 21, true));
        spinner = new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<Game>(this, android.R.layout.simple_spinner_dropdown_item, games));
        root.addView(spinner);

        Button optimize = new Button(this);
        optimize.setText("Ativar modo seguro");
        optimize.setOnClickListener(v -> {
            protection.setText("Modo seguro ativo: sem root, overclock, undervolt, alteração de arquivos ou encerramento forçado de outros apps.");
            status.setText("Pronto. Abra o jogo e use o aparelho normalmente.");
        });
        root.addView(optimize);

        Button launch = new Button(this);
        launch.setText("Abrir jogo selecionado");
        launch.setOnClickListener(v -> launchSelected());
        root.addView(launch);

        root.addView(text("Proteção", 21, true));
        protection = text("O app prioriza desempenho sustentável e temperatura segura.", 15, false);
        root.addView(protection);

        status = text("Pronto para analisar o aparelho.", 15, false);
        root.addView(status);

        TextView supported = text("Suportados: Free Fire, Free Fire MAX, Minecraft, Roblox, Fortnite e Blood Strike.", 14, false);
        root.addView(supported);

        setContentView(scroll);
    }

    private void launchSelected() {
        Game game = (Game) spinner.getSelectedItem();
        PackageManager pm = getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(game.pkg);
        if (intent != null) {
            startActivity(intent);
            status.setText("Abrindo " + game.name + "...");
        } else {
            Toast.makeText(this, game.name + " não está instalado ou não foi encontrado.", Toast.LENGTH_SHORT).show();
        }
    }

    private final Runnable refresh = new Runnable() {
        @Override public void run() { updateInfo(); handler.postDelayed(this, 1500); }
    };

    private void updateInfo() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mem = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mem);
        long used = mem.totalMem - mem.availMem;
        ram.setText(String.format(Locale.getDefault(), "RAM: %.0f MB usados / %.0f MB", used / 1048576.0, mem.totalMem / 1048576.0));

        BatteryManager bm = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
        int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        battery.setText("Bateria: " + level + "%");

        StatFs fs = new StatFs(getFilesDir().getAbsolutePath());
        double freeGb = fs.getAvailableBytes() / 1073741824.0;
        storage.setText(String.format(Locale.getDefault(), "Armazenamento livre: %.1f GB", freeGb));

        String t = "Indisponível nesta versão";
        if (Build.VERSION.SDK_INT >= 29) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            switch (pm.getCurrentThermalStatus()) {
                case PowerManager.THERMAL_STATUS_NONE: t = "Normal"; break;
                case PowerManager.THERMAL_STATUS_LIGHT: t = "Leve"; break;
                case PowerManager.THERMAL_STATUS_MODERATE: t = "Moderado"; break;
                case PowerManager.THERMAL_STATUS_SEVERE: t = "Alto"; break;
                case PowerManager.THERMAL_STATUS_CRITICAL: t = "Crítico"; break;
                case PowerManager.THERMAL_STATUS_EMERGENCY: t = "Emergência"; break;
                case PowerManager.THERMAL_STATUS_SHUTDOWN: t = "Desligamento"; break;
            }
        }
        thermal.setText("Estado térmico: " + t);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
